package com.robby.githubuser.enums

enum class StatusResponse {
    SUCCESS, EMPTY, ERROR
}